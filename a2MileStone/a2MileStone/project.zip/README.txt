README

Course: cs400
Semester: Summer 2019
Porject Name: Milk weight
Student Name: SungHoon Chung

email: chung72@wisc.edu

This GUI program is hardcoded with cvs file.
This program has the button(select files), so it can select the file from desktop.
user can select year, month and day, and write weight.
Thank you.

 